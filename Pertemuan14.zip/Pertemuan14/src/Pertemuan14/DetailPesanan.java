/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pertemuan14;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author LENOVO
 */
@Entity
@Table(name = "detail_pesanan")
@NamedQueries({
    @NamedQuery(name = "DetailPesanan.findAll", query = "SELECT d FROM DetailPesanan d ORDER BY d.idDetail ASC"),
    @NamedQuery(name = "DetailPesanan.findByIdDetail", query = "SELECT d FROM DetailPesanan d WHERE d.idDetail = :idDetail"),
    @NamedQuery(name = "DetailPesanan.findByJumlah", query = "SELECT d FROM DetailPesanan d WHERE d.jumlah = :jumlah"),
    @NamedQuery(name = "DetailPesanan.findBySubtotal", query = "SELECT d FROM DetailPesanan d WHERE d.subtotal = :subtotal")})
public class DetailPesanan implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id_detail")
    private Integer idDetail;
    @Basic(optional = false)
    @Column(name = "jumlah")
    private int jumlah;
    @Basic(optional = false)
    @Column(name = "subtotal")
    private int subtotal;
    @JoinColumn(name = "id_menu", referencedColumnName = "id_menu")
    @ManyToOne
    private Menu idMenu;
    @JoinColumn(name = "id_pesanan", referencedColumnName = "id_pesanan")
    @ManyToOne
    private Pesanan idPesanan;

    public DetailPesanan() {
    }

    public DetailPesanan(Integer idDetail) {
        this.idDetail = idDetail;
    }

    public DetailPesanan(Integer idDetail, int jumlah, int subtotal) {
        this.idDetail = idDetail;
        this.jumlah = jumlah;
        this.subtotal = subtotal;
    }

    public Integer getIdDetail() {
        return idDetail;
    }

    public void setIdDetail(Integer idDetail) {
        this.idDetail = idDetail;
    }

    public int getJumlah() {
        return jumlah;
    }

    public void setJumlah(int jumlah) {
        this.jumlah = jumlah;
        if (this.idMenu != null) {
            this.subtotal = this.idMenu.getHarga() * jumlah; // otomatis
        }
    }

    public int getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(int subtotal) {
        this.subtotal = subtotal;
    }

    public Menu getIdMenu() {
        return idMenu;
    }

    public void setIdMenu(Menu idMenu) {
        this.idMenu = idMenu;
    }

    public Pesanan getIdPesanan() {
        return idPesanan;
    }

    public void setIdPesanan(Pesanan idPesanan) {
        this.idPesanan = idPesanan;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idDetail != null ? idDetail.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof DetailPesanan)) {
            return false;
        }
        DetailPesanan other = (DetailPesanan) object;
        if ((this.idDetail == null && other.idDetail != null) || (this.idDetail != null && !this.idDetail.equals(other.idDetail))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Cafe.DetailPesanan[ idDetail=" + idDetail + " ]";
    }
    
}
