/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pertemuan14;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author LENOVO
 */
@Entity
@Table(name = "pesanan")
@NamedQueries({
    @NamedQuery(name = "Pesanan.findAll", query = "SELECT p FROM Pesanan p ORDER BY p.idPesanan ASC"),
    @NamedQuery(name = "Pesanan.findByIdPesanan", query = "SELECT p FROM Pesanan p WHERE p.idPesanan = :idPesanan"),
    @NamedQuery(name = "Pesanan.findByNamaPelanggan", query = "SELECT p FROM Pesanan p WHERE p.namaPelanggan = :namaPelanggan"),
    @NamedQuery(name = "Pesanan.findByTanggal", query = "SELECT p FROM Pesanan p WHERE p.tanggal = :tanggal")})
public class Pesanan implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id_pesanan")
    private Integer idPesanan;
    @Basic(optional = false)
    @Column(name = "nama_pelanggan")
    private String namaPelanggan;
    @Column(name = "tanggal", insertable = false, updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date tanggal;
    @OneToMany(mappedBy = "idPesanan")
    private Collection<DetailPesanan> detailPesananCollection;

    public Pesanan() {
    }

    public Pesanan(Integer idPesanan) {
        this.idPesanan = idPesanan;
    }

    public Pesanan(Integer idPesanan, String namaPelanggan) {
        this.idPesanan = idPesanan;
        this.namaPelanggan = namaPelanggan;
    }

    public Integer getIdPesanan() {
        return idPesanan;
    }

    public void setIdPesanan(Integer idPesanan) {
        this.idPesanan = idPesanan;
    }

    public String getNamaPelanggan() {
        return namaPelanggan;
    }

    public void setNamaPelanggan(String namaPelanggan) {
        this.namaPelanggan = namaPelanggan;
    }

    public Date getTanggal() {
        return tanggal;
    }

    public void setTanggal(Date tanggal) {
        this.tanggal = tanggal;
    }

    public Collection<DetailPesanan> getDetailPesananCollection() {
        return detailPesananCollection;
    }

    public void setDetailPesananCollection(Collection<DetailPesanan> detailPesananCollection) {
        this.detailPesananCollection = detailPesananCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idPesanan != null ? idPesanan.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Pesanan)) {
            return false;
        }
        Pesanan other = (Pesanan) object;
        if ((this.idPesanan == null && other.idPesanan != null) || (this.idPesanan != null && !this.idPesanan.equals(other.idPesanan))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Cafe.Pesanan[ idPesanan=" + idPesanan + " ]";
    }

}
